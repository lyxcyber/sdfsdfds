<?php
define('DEBUG', false);
define('MYSQL_USER', 'user');
define('MYSQL_PASS', '..yourpassword..');
define('MYSQL_DB_NAME', 'database');
define('PANEL_FOLDER', 'panelcGFuZWxleG9kdXNvY3Rv');
define('STATS_FOLDER', 'statsc3RhdHNmbG9hZGVy');
define('MAIN_FOLDER', 'rootMD50MA');

define('PHP_LOG_PATH', '/var/data/www/php_errors.log');
define('APACHE_LOG_PATH', '/var/data/www/apache_error.log');

