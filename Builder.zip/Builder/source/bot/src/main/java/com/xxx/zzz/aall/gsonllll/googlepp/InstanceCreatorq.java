

package com.xxx.zzz.aall.gsonllll.googlepp;

import java.lang.reflect.Type;


public interface InstanceCreatorq<T> {

  
  public T createInstance(Type type);
}
