#!/bin/bash
sudo  docker build -t builder2 -f Dockerfile .